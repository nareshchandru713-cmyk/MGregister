// api/send.js
// Murugan Stores — daily financial PRE-ALERT (Vercel Serverless Function + Cron).
//
// Triggered by the vercel.json cron at 17:30 UTC (= 23:00 IST). It independently
// pulls TODAY's ledger straight from Firestore using the Firebase Admin SDK
// (no frontend involvement), then emails a two-section executive summary via
// Resend to CLIENT_EMAIL. Kept deliberately lightweight: one Firestore read +
// one in-memory pass, so it never approaches the Hobby-tier execution timeout.
//
// Required environment variables (Vercel → Project → Settings → Environment):
//   FIREBASE_PROJECT_ID      e.g. murugan-stores-1a357
//   FIREBASE_CLIENT_EMAIL    service-account email
//   FIREBASE_PRIVATE_KEY     service-account private key (with literal \n escapes)
//   RESEND_API_KEY           Resend API key
//   CLIENT_EMAIL             destination address for the report
//   CRON_SECRET              (optional) if set, the cron request must present it

import admin from 'firebase-admin';

/* ── Firebase Admin: initialise once and reuse across warm invocations ── */
function getDb() {
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId:   process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        // Vercel stores newlines as the two characters \n — restore real newlines.
        privateKey:  (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
      }),
    });
  }
  return admin.firestore();
}

/* ── Small helpers ── */
const num = v => parseFloat(v) || 0;
const INR = v => '₹' + num(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// Shop-local (IST = UTC+5:30) calendar keys so "today"/"tomorrow" match the app.
const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
const dayKey = ms => new Date(ms + IST_OFFSET_MS).toISOString().slice(0, 10);
const istToday    = () => dayKey(Date.now());
const istTomorrow = () => dayKey(Date.now() + 24 * 60 * 60 * 1000);
const prettyDate  = key => {
  const [y, m, d] = key.split('-');
  return `${d}/${m}/${y}`;
};

/* ── Pull data: one collection-group read, single pass ──
   • today's entry doc → Section 1 (credit)
   • every entry's cheque rows scheduled for tomorrow → Section 2 (pre-alert)   */
async function fetchLedger(db) {
  const today    = istToday();
  const tomorrow = istTomorrow();

  const snap = await db.collectionGroup('entries').get();

  let todayEntry = null;
  const tomorrowCheques = [];

  snap.forEach(doc => {
    const data = doc.data() || {};
    const dateKey = data.date || doc.id;          // entries are keyed by date
    if (dateKey === today) todayEntry = data;

    (data.chequeGroups || []).forEach(g => {
      const vendor = g.vendorName || '—';
      (g.rows || []).forEach(row => {
        if (row.split && Array.isArray(row.disbursedCheques) && row.disbursedCheques.length) {
          // Split row: each disbursed cheque carries its own schedule + status.
          row.disbursedCheques.forEach(s => {
            if (s.chequeScheduleDate === tomorrow && s.status !== 'Cleared') {
              tomorrowCheques.push({
                vendor,
                chequeNo: s.chequeNumber || '—',
                bills: (row.associatedBills || []).join(', ') || '—',
                value: num(s.amount),
              });
            }
          });
        } else if (row.chequeScheduleDate === tomorrow && row.status !== 'Cleared') {
          tomorrowCheques.push({
            vendor,
            chequeNo: row.chequeNo || '—',
            bills: (row.associatedBills || []).join(', ') || '—',
            value: num(row.chequeValue),
          });
        }
      });
    });
  });

  return { today, tomorrow, todayEntry, tomorrowCheques };
}

/* ── Section 1: Daily Credit Report Breakdown ── */
function renderCreditSection(entry) {
  const issued      = (entry && entry.crsale) || [];   // credit extended today
  const collections = (entry && entry.crrecv) || [];   // collections logged today

  const lines = [];
  collections.forEach(r => lines.push({ type: 'Collection',    name: r.name, bill: r.billno, total: num(r.total), paid: num(r.paid), open: num(r.npaid) }));
  issued.forEach(r      => lines.push({ type: 'Credit Issued', name: r.name, bill: r.billno, total: num(r.total), paid: num(r.paid), open: num(r.npaid) }));

  if (!lines.length) {
    return `<p style="margin:0;padding:16px;background:#f7fafc;border-radius:6px;color:#718096;font-size:14px">
      No credit activity was recorded today.
    </p>`;
  }

  const totalCollected = lines.reduce((s, l) => s + l.paid, 0);
  const totalOpen      = lines.reduce((s, l) => s + l.open, 0);

  const rows = lines.map(l => `
    <tr>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#4a5568">${esc(l.type)}</td>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#1a202c;font-weight:600">${esc(l.name) || '—'}</td>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#4a5568">${esc(l.bill) || '—'}</td>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#1a202c;text-align:right">${INR(l.total)}</td>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#16a34a;font-weight:700;text-align:right">${INR(l.paid)}</td>
      <td style="padding:9px 12px;border-bottom:1px solid #edf2f7;font-size:13px;color:#1a202c;text-align:right">${INR(l.open)}</td>
    </tr>`).join('');

  return `
    <table style="width:100%;border-collapse:collapse;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden">
      <thead>
        <tr style="background:#1a365d">
          <th style="padding:10px 12px;text-align:left;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Type</th>
          <th style="padding:10px 12px;text-align:left;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Customer</th>
          <th style="padding:10px 12px;text-align:left;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Bill No</th>
          <th style="padding:10px 12px;text-align:right;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Credit Amount</th>
          <th style="padding:10px 12px;text-align:right;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Collected</th>
          <th style="padding:10px 12px;text-align:right;font-size:11px;color:#cbd5e1;text-transform:uppercase;letter-spacing:.05em">Open Balance</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr style="background:#f7fafc">
          <td colspan="4" style="padding:11px 12px;font-size:13px;font-weight:700;color:#1a202c;text-align:right">Totals</td>
          <td style="padding:11px 12px;font-size:13px;font-weight:800;color:#16a34a;text-align:right">${INR(totalCollected)}</td>
          <td style="padding:11px 12px;font-size:13px;font-weight:800;color:#1a202c;text-align:right">${INR(totalOpen)}</td>
        </tr>
      </tfoot>
    </table>`;
}

/* ── Section 2: [PRE-ALERT] Cheque Commitments Due Tomorrow ── */
function renderChequeAlert(cheques, tomorrowKey) {
  const total = cheques.reduce((s, c) => s + c.value, 0);

  const inner = cheques.length
    ? `<table style="width:100%;border-collapse:collapse;margin-top:12px;background:#fff;border-radius:6px;overflow:hidden">
         <thead>
           <tr style="background:#7f1d1d">
             <th style="padding:9px 12px;text-align:left;font-size:11px;color:#fecaca;text-transform:uppercase;letter-spacing:.05em">Vendor</th>
             <th style="padding:9px 12px;text-align:left;font-size:11px;color:#fecaca;text-transform:uppercase;letter-spacing:.05em">Cheque No</th>
             <th style="padding:9px 12px;text-align:left;font-size:11px;color:#fecaca;text-transform:uppercase;letter-spacing:.05em">Bill(s)</th>
             <th style="padding:9px 12px;text-align:right;font-size:11px;color:#fecaca;text-transform:uppercase;letter-spacing:.05em">Clearing Amount</th>
           </tr>
         </thead>
         <tbody>
           ${cheques.map(c => `
             <tr>
               <td style="padding:9px 12px;border-bottom:1px solid #fee2e2;font-size:13px;color:#1a202c;font-weight:600">${esc(c.vendor)}</td>
               <td style="padding:9px 12px;border-bottom:1px solid #fee2e2;font-size:13px;color:#4a5568">${esc(c.chequeNo)}</td>
               <td style="padding:9px 12px;border-bottom:1px solid #fee2e2;font-size:13px;color:#4a5568">${esc(c.bills)}</td>
               <td style="padding:9px 12px;border-bottom:1px solid #fee2e2;font-size:13px;color:#b91c1c;font-weight:700;text-align:right">${INR(c.value)}</td>
             </tr>`).join('')}
         </tbody>
         <tfoot>
           <tr style="background:#fef2f2">
             <td colspan="3" style="padding:10px 12px;font-size:13px;font-weight:700;color:#7f1d1d;text-align:right">Total Due Tomorrow</td>
             <td style="padding:10px 12px;font-size:14px;font-weight:800;color:#b91c1c;text-align:right">${INR(total)}</td>
           </tr>
         </tfoot>
       </table>`
    : `<p style="margin:12px 0 0;font-size:14px;color:#7f1d1d">No vendor cheques are scheduled to clear tomorrow.</p>`;

  return `
    <div style="border:2px solid #dc2626;border-radius:10px;overflow:hidden">
      <div style="background:#dc2626;padding:12px 16px">
        <span style="font-size:15px;font-weight:800;color:#ffffff;letter-spacing:.02em">⚠️ [PRE-ALERT] Cheque Commitments Due Tomorrow</span>
        <div style="font-size:12px;color:#fecaca;margin-top:2px">Advance layout for ${esc(prettyDate(tomorrowKey))} — before morning bank clearings</div>
      </div>
      <div style="padding:16px;background:#fff5f5">${inner}</div>
    </div>`;
}

/* ── Compose the full executive email ── */
function buildEmailHtml({ today, tomorrow, todayEntry, tomorrowCheques }) {
  return `
  <div style="font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;max-width:680px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
    <div style="background:linear-gradient(135deg,#1a365d,#2c5282);padding:24px">
      <h1 style="margin:0;font-size:20px;color:#ffffff;font-weight:800">Murugan Stores</h1>
      <p style="margin:4px 0 0;font-size:13px;color:#bee3f8">Daily Financial Summary — ${esc(prettyDate(today))}</p>
    </div>
    <div style="padding:24px">
      <h2 style="margin:0 0 12px;font-size:15px;color:#1a365d;font-weight:700">Section 1 · Daily Credit Report Breakdown</h2>
      ${renderCreditSection(todayEntry)}
      <div style="height:28px"></div>
      ${renderChequeAlert(tomorrowCheques, tomorrow)}
    </div>
    <div style="padding:14px 24px;background:#f7fafc;border-top:1px solid #edf2f7">
      <small style="color:#718096;font-size:11px">Automated system notification via MG Register backend · generated ${esc(new Date().toISOString())}</small>
    </div>
  </div>`;
}

/* ── Resend dispatch ── */
async function sendEmail(html, subject) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
    },
    body: JSON.stringify({
      from: 'Murugan Stores Alerts <onboarding@resend.dev>',  // swap for a verified domain later
      to: process.env.CLIENT_EMAIL,
      subject,
      html,
    }),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

/* ── Vercel handler (cron invokes via GET) ── */
export default async function handler(req, res) {
  // Optional hardening: if CRON_SECRET is configured, require it on the request.
  if (process.env.CRON_SECRET && req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    const db = getDb();
    const ledger = await fetchLedger(db);
    const subject = `[PRE-ALERT] Daily Financial Summary - ${prettyDate(ledger.today)}`;
    const html = buildEmailHtml(ledger);
    const { ok, data } = await sendEmail(html, subject);
    if (ok) {
      return res.status(200).json({ success: true, reportDate: ledger.today, chequesDueTomorrow: ledger.tomorrowCheques.length, id: data && data.id });
    }
    return res.status(400).json({ success: false, error: data });
  } catch (error) {
    console.error('send.js failed:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
}
